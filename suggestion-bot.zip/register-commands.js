import { REST, Routes, SlashCommandBuilder } from "discord.js";

const token = process.env.DISCORD_TOKEN;
const clientId = process.env.DISCORD_CLIENT_ID;
const guildId = process.env.DISCORD_GUILD_ID; // optional: for instant guild-scoped registration

if (!token || !clientId) {
  console.error("❌ DISCORD_TOKEN and DISCORD_CLIENT_ID must be set.");
  process.exit(1);
}

const commands = [
  new SlashCommandBuilder()
    .setName("suggest")
    .setDescription("Submit a suggestion for the game")
    .addStringOption((option) =>
      option
        .setName("suggestion")
        .setDescription("Your suggestion")
        .setRequired(true)
        .setMaxLength(1000)
    ),
  new SlashCommandBuilder()
    .setName("suggestion-delete")
    .setDescription("Delete one of your own suggestions")
    .addIntegerOption((option) =>
      option
        .setName("number")
        .setDescription("The suggestion number to delete (e.g. 3)")
        .setRequired(true)
        .setMinValue(1)
    ),
].map((cmd) => cmd.toJSON());

const rest = new REST({ version: "10" }).setToken(token);

async function register() {
  try {
    console.log("🔄 Registering slash commands...");

    if (guildId) {
      // Guild-scoped: instant, great for testing
      await rest.put(Routes.applicationGuildCommands(clientId, guildId), {
        body: commands,
      });
      console.log(`✅ Commands registered to guild ${guildId} (instant)`);
    } else {
      // Global: takes up to 1 hour to propagate
      await rest.put(Routes.applicationCommands(clientId), {
        body: commands,
      });
      console.log("✅ Commands registered globally (may take up to 1 hour to appear)");
    }
  } catch (error) {
    console.error("❌ Failed to register commands:", error);
  }
}

register();
